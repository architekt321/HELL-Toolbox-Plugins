"""Official MIRO Firmware Cleaner plugin."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

from miro.events import EventBus
from miro.plugins import Plugin
from miro.workflow import WorkflowContext


@dataclass(slots=True, frozen=True)
class CleanupCandidate:
    """One cleanup candidate."""

    relative_path: str
    absolute_path: Path
    exists: bool
    removed: bool


class FirmwareCleanerPlugin(Plugin):
    """Safe rule-based firmware cleanup plugin."""

    plugin_id = "firmware_cleaner"
    name = "MIRO Firmware Cleaner"

    def __init__(self) -> None:
        self.root = Path(__file__).resolve().parent
        self.rules_path = self.root / "rules.toml"

    def register_events(
        self,
        event_bus: EventBus,
    ) -> None:
        """Register optional firmware workflow event handlers."""

        event_bus.subscribe(
            "firmware.workflow.started",
            self._on_firmware_started,
        )

    def workflow_steps(self):
        """Provide one optional firmware cleanup step."""

        return (
            (
                "firmware_cleaner",
                "Clean firmware",
                self.clean_from_context,
                ("extract",),
            ),
        )

    def load_rules(self) -> tuple[str, ...]:
        """Load validated relative cleanup paths."""

        if not self.rules_path.is_file():
            raise FileNotFoundError(f"Cleaner rules do not exist: {self.rules_path}")

        with self.rules_path.open("rb") as handle:
            data = tomllib.load(handle)

        paths = data.get("paths", [])

        if not (
            isinstance(paths, list) and all(isinstance(item, str) for item in paths)
        ):
            raise ValueError("Cleaner rule 'paths' must be a string list.")

        normalized: list[str] = []

        for value in paths:
            clean = value.strip().strip("/")

            if not clean:
                continue

            candidate = Path(clean)

            if candidate.is_absolute() or ".." in candidate.parts:
                raise ValueError(f"Unsafe cleanup path: {value}")

            normalized.append(candidate.as_posix())

        return tuple(normalized)

    def scan(
        self,
        firmware_root: Path | str,
    ) -> tuple[CleanupCandidate, ...]:
        """Scan configured cleanup paths without removing anything."""

        root = Path(firmware_root).expanduser().resolve()
        candidates: list[CleanupCandidate] = []

        for relative in self.load_rules():
            absolute = (root / relative).resolve()

            try:
                absolute.relative_to(root)
            except ValueError as exc:
                raise ValueError(
                    f"Cleanup path escaped firmware root: {relative}"
                ) from exc

            candidates.append(
                CleanupCandidate(
                    relative_path=relative,
                    absolute_path=absolute,
                    exists=absolute.exists(),
                    removed=False,
                )
            )

        return tuple(candidates)

    def clean(
        self,
        firmware_root: Path | str,
        *,
        apply: bool = False,
    ) -> tuple[CleanupCandidate, ...]:
        """Scan or explicitly remove configured paths."""

        scanned = self.scan(firmware_root)

        if not apply:
            return scanned

        cleaned: list[CleanupCandidate] = []

        for candidate in scanned:
            removed = False

            if candidate.exists:
                if candidate.absolute_path.is_dir():
                    import shutil

                    shutil.rmtree(candidate.absolute_path)
                else:
                    candidate.absolute_path.unlink()

                removed = True

            cleaned.append(
                CleanupCandidate(
                    relative_path=candidate.relative_path,
                    absolute_path=candidate.absolute_path,
                    exists=candidate.exists,
                    removed=removed,
                )
            )

        return tuple(cleaned)

    def clean_from_context(
        self,
        context: WorkflowContext,
    ) -> tuple[CleanupCandidate, ...]:
        """Workflow adapter using firmware_root and cleanup_apply."""

        firmware_root = context.values.get("firmware_root")

        if firmware_root is None:
            raise RuntimeError("Workflow context is missing 'firmware_root'.")

        apply = bool(context.values.get("cleanup_apply", False))

        result = self.clean(
            firmware_root,
            apply=apply,
        )
        context.values["firmware_cleanup"] = result
        return result

    @staticmethod
    def _on_firmware_started(event) -> None:
        """Reserved lightweight event hook."""

        return
